
singleton Material(wheel_hu2)
{
   mapTo = "wheel_hu2";
   diffuseColor[0] = "0.256 0.256 0.256 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "5";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseColor[1] = "0.8 0.8 0.8 0.81";
   diffuseMap[0] = "vehicles/common/wheels/hura/wheel_hu2.png";
   diffuseMap[1] = "vehicles/common/wheels/hura/wheel_hu2.png";
   specularPower[1] = "29";
   specularStrength[1] = "0.392157";
   specularMap[1] = "vehicles/common/wheels/hura/1.png";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(hura_wheel2)
{
   mapTo = "hura_wheel2";
   diffuseColor[0] = "0.256 0.256 0.256 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "5";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseColor[1] = "0.8 0.8 0.8 0.81";
   diffuseMap[0] = "vehicles/common/wheels/hura/wheel2.png";
   diffuseMap[1] = "vehicles/common/wheels/hura/wheel2.png";
   specularPower[1] = "29";
   specularStrength[1] = "0.392157";
   specularMap[1] = "vehicles/common/wheels/hura/1.png";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};
