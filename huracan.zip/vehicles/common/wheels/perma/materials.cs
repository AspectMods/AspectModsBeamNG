singleton Material(EXT_RIM)
{
    mapTo = "EXT_RIM";
   diffuseColor[0] = "0.843137 0.843137 0.843137 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseColor[1] = "1 1 1 0.744";
   diffuseMap[0] = "vehicles/common/wheels/perma/coffee.tga";
   diffuseMap[1] = "vehicles/common/wheels/perma/coffee.tga";
   specularPower[1] = "21";
   specularStrength[1] = "1.76471";
   specularMap[1] = "vehicles/common/wheels/perma/1.png";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "Miscellaneous";
};

singleton Material(EXT_RIM2)
{
    mapTo = "EXT_RIM2";
   diffuseColor[0] = "0.843137 0.843137 0.843137 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseColor[1] = "1 1 1 0.744";
   diffuseMap[0] = "vehicles/common/wheels/perma/black.tga";
   diffuseMap[1] = "vehicles/common/wheels/perma/black.tga";
   specularPower[1] = "21";
   specularStrength[1] = "1.76471";
   specularMap[1] = "vehicles/common/wheels/perma/1.png";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "Miscellaneous";
};