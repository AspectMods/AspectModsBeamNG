
singleton Material(interior_huracan)
{
    mapTo = "interior_huracan";
	diffuseMap[0] = "interior_lod0.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(black_huracan)
{
    mapTo = "black_huracan";
	diffuseMap[0] = "tx.png";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(huracan_dash)
{
    mapTo = "huracan_dash";
	diffuseMap[0] = "CLluster.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(lights_huracan)
{
    mapTo = "lights_huracan";
	diffuseMap[0] = "lights_lod0.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(nodam_huracan)
{
    mapTo = "nodam_huracan";
	diffuseMap[0] = "nodamage_lod0.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(chassis_huracan_TXT)
{
    mapTo = "chassis_huracan_TXT";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/common/null.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.6";
    specularPower[0] = "16";
    specularPower[1] = "16";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    beamngDiffuseColorSlot = 1;
    doubleSided = "1";
    dynamicCubemap = true;
};

singleton Material(chassis_huracan_TXT2)
{
    mapTo = "chassis_huracan_TXT2";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
    diffuseMap[2] = "chassis_c.png";
    specularMap[2] = "chassis_s.png";
    normalMap[2] = "chassis_n.png";
    diffuseMap[1] = "chassis.png";
    specularMap[1] = "chassis_s.png";
    normalMap[1] = "chassis_n.png";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "chassis_n.png";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(huracan_glass)
{
    mapTo = "huracan_glass";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/super/super_glass_d.dds";
    opacityMap[0] = "vehicles/super/super_glass_d.dds";
    diffuseMap[1] = "vehicles/super/super_glass_da.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(huracan_glass_int)
{
    mapTo = "huracan_glass_int";
    diffuseMap[0] = "vehicles/super/super_glass_d.dds";
    specularMap[0] = "vehicles/common/null.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    doubleSided = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(huracan_glass_dmg)
{
    mapTo = "huracan_glass_dmg";
    diffuseMap[0] = "vehicles/huracan/razbitoe-steklo-25.png";
    opacityMap[0] = "vehicles/super/super_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/super/super_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(huracan_windshield_dmg)
{
    mapTo = "huracan_windshield_dmg";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/super/super_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/windshield_dmg_n.dds";
    specularPower[0] = "32";
    diffuseColor[0] = "1.5 1.5 1.5 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(grey_perma)
{
    mapTo = "grey_perma";
diffuseMap[0] = "images.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "0";
};

singleton Material(silver_perma)
{
    mapTo = "silver_perma";
diffuseMap[0] = "images.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "0";
};

singleton Material(chrome_perma)
{
    mapTo = "chrome_perma";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/mirror_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(huracan_reverselight)
{
    mapTo = "huracan_reverselight";
};

singleton Material(huracan_signal_R)
{
    mapTo = "huracan_signal_R";
};

singleton Material(huracan_signal_L)
{
    mapTo = "huracan_signal_L";
};

singleton Material(huracan_taillight_L)
{
    mapTo = "huracan_taillight_L";
};

singleton Material(huracan_taillight_R)
{
    mapTo = "huracan_taillight_R";
};

singleton Material(huracan_headlight)
{
    mapTo = "huracan_headlight";
};

singleton Material(huracan_highbeam)
{
    mapTo = "huracan_highbeam";
};

singleton Material(huracan_chmsl)
{
    mapTo = "huracan_chmsl";
};

singleton Material(huracan_running)
{
    mapTo = "huracan_running";
};

singleton Material(huracan_lights)
{
    mapTo = "huracan_lights";
	diffuseMap[0] = "lights_lod0.jpg";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    doubleSided = "0";
    translucentZWrite = "1";
};

singleton Material(huracan_lights_on)
{
   mapTo = "huracan_lights_on";
   diffuseMap[0] = "lights_on.jpg";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(huracan_signal)
{
    mapTo = "huracan_signal";
   diffuseMap[1] = "orangeyellow.png";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "32";
   pixelSpecular[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucentBlendOp = "None";
   alphaTest = "0";
   alphaRef = "0";
    glow[1] = "0";
    emissive[1] = "1";
   dynamicCubemap = true;
   materialTag0 = "beamng"; materialTag1 = "vehicle";	
};

singleton Material(huracan_signal_on)
{
    mapTo = "huracan_signal_on";
   diffuseMap[1] = "orangeyellow.png";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "32";
   pixelSpecular[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucentBlendOp = "None";
   alphaTest = "0";
   alphaRef = "0";
    glow[1] = "1";
    emissive[1] = "1";
   dynamicCubemap = true;
   materialTag0 = "beamng"; materialTag1 = "vehicle";	
};

singleton Material(huracan_brakes)
{
    mapTo = "huracan_brakes";
   diffuseMap[1] = "red.png";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "32";
   pixelSpecular[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucentBlendOp = "None";
   alphaTest = "0";
   alphaRef = "0";
    glow[1] = "0";
    emissive[1] = "1";
   dynamicCubemap = true;
   materialTag0 = "beamng"; materialTag1 = "vehicle";	
};

singleton Material(huracan_brakes_on)
{
    mapTo = "huracan_brakes_on";
   diffuseMap[1] = "red.png";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "32";
   pixelSpecular[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucentBlendOp = "None";
   alphaTest = "0";
   alphaRef = "0";
    glow[1] = "1";
    emissive[1] = "1";
   dynamicCubemap = true;
   materialTag0 = "beamng"; materialTag1 = "vehicle";	
};

singleton Material(huracan_brakes_on_intense)
{
    mapTo = "huracan_brakes_on_intense";
   diffuseMap[1] = "red1.png";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "32";
   pixelSpecular[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucentBlendOp = "None";
   alphaTest = "0";
   alphaRef = "0";
    glow[1] = "1";
    emissive[1] = "1";
   dynamicCubemap = true;
   materialTag0 = "beamng"; materialTag1 = "vehicle";	
};

singleton Material(super_interior)
{
    mapTo = "super_interior";
    normalMap[0] = "vehicles/super/super_interior_n.dds";
    diffuseMap[0] = "vehicles/super/super_interior_d.dds";
    specularMap[0] = "vehicles/super/super_interior_s.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    specularPower[1] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblurred";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
