
singleton Material(SVTFocus)
{
    mapTo = "SVTFocus";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.7";
    specular[0] = "0 0 0 1";
    specularPower[1] = "80";
    translucent = "0";
    diffuseColor[1] = "1 1 1 0.423";
    diffuseColor[2] = "1 1 1 0.664";
    diffuseMap[0] = "vehicles/SVTFocus/TXT/chassis.dds";
    diffuseMap[1] = "vehicles/SVTFocus/TXT/chassis.dds";
    diffuseMap[2] = "vehicles/SVTFocus/TXT/chassis.dds";
    specularMap[0] = "vehicles/SVTFocus/TXT/1.dds";
    specularMap[1] = "vehicles/SVTFocus/TXT/1.dds";
    specularMap[2] = "vehicles/SVTFocus/TXT/1.dds";
    //specularMap[2] = "vehicles/SVTFocus/TXT/1.png";
    //normalMap[0] = "vehicles/SVTFocus/TXT/NormalMap.dds";
    //normalMap[1] = "vehicles/SVTFocus/TXT/NormalMap.dds";
    materialTag0 = "Miscellaneous";
    useAnisotropic[1] = "1";
    alphaRef = "255";
    alphaTest = "0";
    doubleSided = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(SVTFocus_glass)
{
    mapTo = "SVTFocus_glass";
    reflectivityMap[0] = "vehicles/SVTFocus/TXT/glass_base.dds";
    diffuseMap[0] = "vehicles/SVTFocus/TXT/glass_base_2.dds";
    opacityMap[0] = "vehicles/SVTFocus/TXT/glass_base.dds";
    diffuseMap[1] = "vehicles/SVTFocus/TXT/glass_base_2.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(SVTFocus_glass_dmg)
{
    mapTo = "SVTFocus_glass_dmg";
    diffuseMap[0] = "vehicles/SVTFocus/TXT/razbitoe-steklo-25.png";
    opacityMap[0] = "vehicles/hatch/hatch_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/hatch/hatch_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(SVTFocus_interior)
{
   mapTo = "SVTFocus_interior";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/interior_lod0.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_gauges_misc)
{
   mapTo = "SVTFocus_gauges_misc";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/glass.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_interior_lights)
{
   mapTo = "SVTFocus_interior_lights";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_interior_misc)
{
   mapTo = "SVTFocus_interior_misc";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_engine)
{
   mapTo = "SVTFocus_engine";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/engine.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_lights_lod0)
{
   mapTo = "SVTFocus_lights_lod0";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/lights_lod0.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_taillight_glass)
{
   mapTo = "SVTFocus_taillight_glass";
    reflectivityMap[0] = "vehicles/SVTFocus/TXT/glass_base.dds";
    diffuseMap[0] = "vehicles/SVTFocus/TXT/lights_lod0.png";
    opacityMap[0] = "vehicles/SVTFocus/TXT/glass_base.dds";
    diffuseMap[1] = "vehicles/SVTFocus/TXT/lights_lod0.png";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(SVTFocus_nodamage)
{
   mapTo = "SVTFocus_nodamage";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/nodamage_lod0.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_mirrors)
{
   mapTo = "SVTFocus_mirrors";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/mirror_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(SVTFocus_chrome)
{
   mapTo = "SVTFocus_chrome";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/remap.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_chassis)
{
   mapTo = "SVTFocus_chassis";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/forza_chassi.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_underbody)
{
   mapTo = "SVTFocus_underbody";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/forza_underbody.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_reverselight)
{
    mapTo = "SVTFocus_reverselight";
};

singleton Material(SVTFocus_signal_R)
{
    mapTo = "SVTFocus_signal_R";
};

singleton Material(SVTFocus_signal_L)
{
    mapTo = "SVTFocus_signal_L";
};

singleton Material(SVTFocus_signal_FR)
{
    mapTo = "SVTFocus_signal_FR";
};

singleton Material(SVTFocus_signal_FL)
{
    mapTo = "SVTFocus_signal_FL";
};

singleton Material(SVTFocus_highbeam)
{
    mapTo = "SVTFocus_highbeam";
};

singleton Material(SVTFocus_lowbeam)
{
    mapTo = "SVTFocus_lowbeam";
};

singleton Material(SVTFocus_foglight)
{
    mapTo = "SVTFocus_foglight";
};

singleton Material(SVTFocus_chmsl)
{
    mapTo = "SVTFocus_chmsl";
};

singleton Material(SVTFocus_taillight_L)
{
    mapTo = "SVTFocus_taillight_L";
};

singleton Material(SVTFocus_taillight_R)
{
    mapTo = "SVTFocus_taillight_R";
};

singleton Material(SVTFocus_lights)
{
   mapTo = "SVTFocus_lights";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_lights_on)
{
   mapTo = "SVTFocus_lights_on";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights_on.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(SVTFocus_lights_on_2)
{
   mapTo = "SVTFocus_lights_on_2";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights_on_2.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(SVTFocus_signal_on)
{
   mapTo = "SVTFocus_signal_on";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/orangeyellow.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(SVTFocus_brakes_on)
{
   mapTo = "SVTFocus_brakes_on";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/RED1.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(SVTFocus_lights_misc)
{
   mapTo = "SVTFocus_lights_misc";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/vehiclelights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_rim)
{
   mapTo = "SVTFocus_rim";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/silver.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVT_lettering)
{
   mapTo = "SVT_lettering";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/silver.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(SVTFocus_wheelcap)
{
   mapTo = "SVTFocus_wheelcap";
   diffuseMap[0] = "vehicles/SVTFocus/TXT/black.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};
