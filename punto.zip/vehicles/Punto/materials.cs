
singleton Material(Punto)
{
    mapTo = "Punto";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.7";
    specular[0] = "0 0 0 1";
    specularPower[1] = "80";
    translucent = "0";
    diffuseColor[1] = "1 1 1 0.423";
    diffuseColor[2] = "1 1 1 0.664";
    diffuseMap[0] = "vehicles/Punto/TXT/chassis.dds";
    diffuseMap[1] = "vehicles/Punto/TXT/chassis.dds";
    diffuseMap[2] = "vehicles/Punto/TXT/chassis.dds";
    specularMap[0] = "vehicles/Punto/TXT/1.dds";
    specularMap[1] = "vehicles/Punto/TXT/1.dds";
    specularMap[2] = "vehicles/Punto/TXT/1.dds";
    //specularMap[2] = "vehicles/Punto/TXT/1.png";
    //normalMap[0] = "vehicles/Punto/TXT/NormalMap.dds";
    //normalMap[1] = "vehicles/Punto/TXT/NormalMap.dds";
    materialTag0 = "Miscellaneous";
    useAnisotropic[1] = "1";
    alphaRef = "255";
    alphaTest = "0";
    doubleSided = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(Punto_glass)
{
    mapTo = "Punto_glass";
    reflectivityMap[0] = "vehicles/Punto/TXT/glass_base.dds";
    diffuseMap[0] = "vehicles/Punto/TXT/glass_base_2.dds";
    opacityMap[0] = "vehicles/Punto/TXT/glass_base.dds";
    diffuseMap[1] = "vehicles/Punto/TXT/glass_base_2.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(Punto_glass_dmg)
{
    mapTo = "Punto_glass_dmg";
    diffuseMap[0] = "vehicles/Punto/TXT/razbitoe-steklo-25.png";
    opacityMap[0] = "vehicles/hatch/hatch_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/Punto/TXT/razbitoe-steklo-25.png";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(Punto_interior)
{
   mapTo = "Punto_interior";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/interior.png";
   diffuseMap[1] = "vehicles/Punto/TXT/interior.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_interior_misc)
{
   mapTo = "Punto_interior_misc";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/interior_lod0.png";
   diffuseMap[1] = "vehicles/Punto/TXT/interior_lod0.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_nodamage)
{
   mapTo = "Punto_nodamage";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/nodamage.png";
   diffuseMap[1] = "vehicles/Punto/TXT/nodamage.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_screen)
{
   mapTo = "Punto_screen";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/screen.png";
   diffuseMap[1] = "vehicles/Punto/TXT/screen.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_mirrors)
{
   mapTo = "Punto_mirrors";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/mirror_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(Punto_chrome)
{
   mapTo = "Punto_chrome";
   diffuseMap[0] = "vehicles/Punto/TXT/remap.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(Punto_silver)
{
   mapTo = "Punto_silver";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/silver.png";
   diffuseMap[1] = "vehicles/Punto/TXT/silver.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_gray)
{
   mapTo = "Punto_gray";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/black.png";
   diffuseMap[1] = "vehicles/Punto/TXT/black.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_darkgray)
{
   mapTo = "Punto_darkgray";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/black.png";
   diffuseMap[1] = "vehicles/Punto/TXT/black.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_red)
{
   mapTo = "Punto_red";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/RED.png";
   diffuseMap[1] = "vehicles/Punto/TXT/RED.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_undercarriage)
{
   mapTo = "Punto_undercarriage";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/Punto/TXT/undercarriage.png";
   diffuseMap[1] = "vehicles/Punto/TXT/undercarriage.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(Punto_reverselight)
{
    mapTo = "Punto_reverselight";
};

singleton Material(Punto_signal_R)
{
    mapTo = "Punto_signal_R";
};

singleton Material(Punto_signal_L)
{
    mapTo = "Punto_signal_L";
};

singleton Material(Punto_highbeam)
{
    mapTo = "Punto_highbeam";
};

singleton Material(Punto_lowbeam)
{
    mapTo = "Punto_lowbeam";
};

singleton Material(Punto_foglight)
{
    mapTo = "Punto_foglight";
};

singleton Material(Punto_foglight_R)
{
    mapTo = "Punto_foglight_R";
};

singleton Material(Punto_chmsl)
{
    mapTo = "Punto_chmsl";
};

singleton Material(Punto_taillight)
{
    mapTo = "Punto_taillight";
};

singleton Material(Punto_lights)
{
   mapTo = "Punto_lights";
   diffuseMap[0] = "vehicles/Punto/TXT/lights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(Punto_signal_on)
{
   mapTo = "Punto_signal_on";
   diffuseMap[0] = "vehicles/Punto/TXT/orangeyellow.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(Punto_brakes_on)
{
   mapTo = "Punto_brakes_on";
   diffuseMap[0] = "vehicles/Punto/TXT/RED.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(Punto_lights_on)
{
   mapTo = "Punto_lights_on";
   diffuseMap[0] = "vehicles/Punto/TXT/white.png";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "0";
   translucentZWrite = "0";
   glow[0] = "1";
   emissive[0] = "1";
};

singleton Material(Punto_lights_misc)
{
   mapTo = "Punto_lights_misc";
   diffuseMap[0] = "vehicles/Punto/TXT/lights.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(Punto_rim)
{
   mapTo = "Punto_rim";
   diffuseMap[0] = "vehicles/Punto/TXT/wheel.png";
   diffuseColor[0] = "1 1 1 0.1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};
