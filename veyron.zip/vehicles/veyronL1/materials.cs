
singleton Material(super)
{
   mapTo = "super";
   diffuseMap[2] = "vehicles/veyronL1/super_c.dds";
   specularMap[2] = "vehicles/veyronL1/super_s.dds";
   normalMap[2] = "vehicles/veyronL1/super_n.dds";
   diffuseMap[1] = "vehicles/veyronL1/super_d.dds";
   specularMap[1] = "vehicles/veyronL1/super_s.dds";
   normalMap[1] = "vehicles/veyronL1/super_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   normalMap[0] = "vehicles/veyronL1/super_n.dds";
   //diffuseMap[3] = "vehicles/super/super_dirt.dds";
   //normalMap[3] = "vehicles/super/super_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   diffuseColor[2] = "0.1 0.4 0.8 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   //diffuseColor[3] = "1.5 1.5 1.5 1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   beamngDiffuseColorSlot = 2;
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_glass)
{
   mapTo = "super_glass";
   diffuseMap[0] = "vehicles/veyronL1/super_glass_d.dds";
   specularMap[0] = "vehicles/veyronL1/super_glass_s.dds";
   diffuseMap[1] = "vehicles/veyronL1/super_glass_da.dds";
   specularMap[1] = "vehicles/veyronL1/super_glass_s.dds";
   //diffuseMap[2] = "vehicles/super/super_glass_dirt.dds";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   specularPower[1] = "128";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   //diffuseColor[2] = "1.5 1.5 1.5 1";
   castShadows = "0";
   translucent = "1";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_glass_dmg)
{
   mapTo = "super_glass_dmg";
   diffuseMap[0] = "vehicles/veyronL1/super_glass_dmg_d.dds";
   specularMap[0] = "vehicles/common/glass_dmg_s.dds";
   normalMap[0] = "vehicles/common/glass_dmg_n.dds";
   //diffuseMap[2] = "vehicles/super/super_glass_dirt.dds";
   specularPower[0] = "32";
   diffuseColor[0] = "1.5 1.5 1.5 1";
   useAnisotropic[0] = "1";
   //diffuseColor[2] = "1.5 1.5 1.5 1";
   castShadows = "0";
   translucent = "1";
   alphaTest = "1";
   alphaRef = "0";
   //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_gauges)
{
   mapTo = "super_gauges";
   diffuseMap[0] = "super_gauges_d.dds";
   specularMap[0] = "super_gauges_s.dds";
   normalMap[0] = "super_gauges_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   diffuseColor[0] = "1 1 1 1";
};

singleton Material(super_gauges_on)
{
   mapTo = "super_gauges_on";
   diffuseMap[1] = "super_gauges_d.dds";
   specularMap[1] = "super_gauges_s.dds";
   normalMap[1] = "super_gauges_n.dds";
   diffuseMap[0] = "super_gauges_d.dds";
   specularMap[0] = "super_gauges_s.dds";
   normalMap[0] = "super_gauges_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   glow[1] = "1";
   emissive[1] = "1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1.5 1.5 1.5 0.2";
};

singleton Material(super_interior)
{
   mapTo = "super_interior";
   diffuseMap[0] = "super_interior_d.dds";
   normalMap[0] = "super_interior_n.dds";
   specularPower[0] = "12";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   specularMap[0] = "super_interior_s.dds";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   diffuseColor[0] = "0.8 0.8 0.8 1";
};

singleton Material(super_lights)
{
   mapTo = "super_lights";
   diffuseMap[1] = "vehicles/veyronL1/super_lights_d.dds";
   specularMap[1] = "vehicles/veyronL1/super_lights_s.dds";
   normalMap[1] = "vehicles/veyronL1/super_lights_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   normalMap[0] = "vehicles/veyronL1/super_lights_n.dds";
   //diffuseMap[2] = "vehicles/super/super_lights_dirt.dds";
   //normalMap[2] = "vehicles/super/super_lights_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   //diffuseColor[2] = "1.5 1.5 1.5 1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   diffuseColor[1] = "1.5 1.5 1.5 1";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_lights_on)
{
   mapTo = "super_lights_on";
   diffuseMap[2] = "vehicles/veyronL1/super_lights_g.dds";
   specularMap[2] = "vehicles/veyronL1/super_lights_s.dds";
   normalMap[2] = "vehicles/veyronL1/super_lights_n.dds";
   diffuseMap[1] = "vehicles/veyronL1/super_lights_d.dds";
   specularMap[1] = "vehicles/veyronL1/super_lights_s.dds";
   normalMap[1] = "vehicles/veyronL1/super_lights_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   normalMap[0] = "vehicles/veyronL1/super_lights_n.dds";
   //diffuseMap[3] = "vehicles/super/super_lights_dirt.dds";
   //normalMap[3] = "vehicles/super/super_lights_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1.5 1.5 1.5 1";
   diffuseColor[2] = "1.5 1.5 1.5 0.12";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   //diffuseColor[3] = "1.5 1.5 1.5 1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   glow[2] = "1";
   emissive[2] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_lights_on_intense)
{
   mapTo = "super_lights_on_intense";
   diffuseMap[2] = "vehicles/veyronL1/super_lights_g.dds";
   specularMap[2] = "vehicles/veyronL1/super_lights_s.dds";
   normalMap[2] = "vehicles/veyronL1/super_lights_n.dds";
   diffuseMap[1] = "vehicles/veyronL1/super_lights_d.dds";
   specularMap[1] = "vehicles/veyronL1/super_lights_s.dds";
   normalMap[1] = "vehicles/veyronL1/super_lights_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   normalMap[0] = "vehicles/veyronL1/super_lights_n.dds";
   //diffuseMap[3] = "vehicles/super/super_lights_dirt.dds";
   //normalMap[3] = "vehicles/super/super_lights_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1.5 1.5 1.5 1";
   diffuseColor[2] = "1.5 1.5 1.5 0.20";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   //diffuseColor[3] = "1.5 1.5 1.5 1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   glow[2] = "1";
   emissive[2] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_lights_dmg)
{
   mapTo = "super_lights_dmg";
   diffuseMap[1] = "vehicles/veyronL1/super_lights_dmg_d.dds";
   specularMap[1] = "vehicles/veyronL1/super_lights_dmg_s.dds";
   normalMap[1] = "vehicles/veyronL1/super_lights_dmg_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   normalMap[0] = "vehicles/veyronL1/super_lights_dmg_n.dds";
   //diffuseMap[2] = "vehicles/super/super_lights_dirt.dds";
   //normalMap[2] = "vehicles/super/super_lights_dmg_n.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   //diffuseColor[2] = "1.5 1.5 1.5 1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   diffuseColor[1] = "1.5 1.5 1.5 1";
   cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(super_signal_L)
{
   mapTo = "super_signal_L";
};

singleton Material(super_signal_R)
{
   mapTo = "super_signal_R";
};

singleton Material(super_brakelight)
{
   mapTo = "super_brakelight";
};

singleton Material(super_parkinglight)
{
   mapTo = "super_parkinglight";
};

singleton Material(super_headlight)
{
   mapTo = "super_headlight";
};

singleton Material(super_reverselight)
{
   mapTo = "super_reverselight";
};

singleton Material(veyronL1_Matte__7D000000__spec_trans_)
{
   mapTo = "Matte__7D000000__spec_trans_";
   diffuseColor[0] = "0.0941177 0.0941177 0.0941177 1";
   specularPower[0] = "4";
   translucentBlendOp = "Add";
   specular[0] = "0.407843 0.407843 0.407843 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   translucent = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(veyronL1_Matte__FF999999__env_25_spec_)
{
   mapTo = "Matte__FF999999__env_25_spec_";
   diffuseMap[2] = "vehicles/veyronL1/lega_d.dds";
   specularMap[2] = "vehicles/veyronL1/lega_s.dds";
   normalMap[2] = "vehicles/veyronL1/lega_n.dds";
   diffuseMap[1] = "vehicles/veyronL1/lega_d.dds";
   specularMap[1] = "vehicles/veyronL1/lega_s.dds";
   normalMap[1] = "vehicles/veyronL1/lega_n.dds";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "0 0 0 1";
   diffuseColor[1] = "1 1 1 1";
   diffuseColor[2] = "0 0 0 0";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   beamngDiffuseColorSlot = 2;
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   doubleSided = "1";
};

singleton Material(veyronL1_brakedisc_s)
{
   mapTo = "brakedisc_s";
   diffuseMap[0] = "vehicles/veyronL1/brakedisc_s";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(veyronL1_veyron_wheel)
{
   mapTo = "veyron_wheel";
   diffuseMap[0] = "vehicles/veyronL1/veyron_wheel";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.25098 0.25098 0.25098 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(veyronL1_veyron_tread)
{
   mapTo = "veyron_tread";
   diffuseMap[0] = "vehicles/veyronL1/veyron_tread";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.254902 0.254902 0.254902 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(veyronL1_vehiclelights128__spec_trans_RR_)
{
   mapTo = "vehiclelights128__spec_trans_RR_";
   diffuseColor[0] = "0.996078 0.00784314 0.0313726 1";
   specularPower[0] = "34";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
   minnaertConstant[0] = "1.3";
};

singleton Material(veyronL1_veyron_lights)
{
   mapTo = "veyron_lights";
   diffuseMap[0] = "vehicles/veyronL1/veyron_lights";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_vehiclelights128__spec_trans_RL_)
{
   mapTo = "vehiclelights128__spec_trans_RL_";
   diffuseColor[0] = "1 0 0.0235294 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   minnaertConstant[0] = "1.2";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_remap_veyron__prim_env_6_spec_)
{
   mapTo = "remap_veyron__prim_env_6_spec_";
   diffuseMap[1] = "vehicles/veyronL1/lega_d2.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "0 0 0 1";
   diffuseColor[1] = "0.0901961 0.0901961 0.0901961 1";
   diffuseColor[2] = "0.00392157 0.00392157 0.00392157 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   beamngDiffuseColorSlot = 2;
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   doubleSided = "1";
};

singleton Material(veyronL1_veyron_misc)
{
   mapTo = "veyron_misc";
   diffuseMap[0] = "vehicles/veyronL1/veyron_misc";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.513726 0.513726 0.513726 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_badges__trans_)
{
   mapTo = "veyron_badges__trans_";
   diffuseMap[0] = "vehicles/veyronL1/veyron_badges";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "140";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_vehiclelights128__spec_FL_)
{
   mapTo = "vehiclelights128__spec_FL_";
   diffuseColor[0] = "0.996078 0.996078 0.992157 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   minnaertConstant[0] = "1.3";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_vehiclelights128__spec_FR_)
{
   mapTo = "vehiclelights128__spec_FR_";
   diffuseColor[0] = "0.992157 0.996078 0.996078 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   minnaertConstant[0] = "1.3";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_Matte__FF000000__spec_)
{
   mapTo = "Matte__FF000000__spec_";
   diffuseColor[0] = "0.0784314 0.0784314 0.0784314 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   minnaertConstant[0] = "-18";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_carpback__spec_)
{
   mapTo = "carpback__spec_";
   specular[0] = "0.29 0.29 0.29 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_carplate__spec_)
{
   mapTo = "carplate__spec_";
   specular[0] = "0.29 0.29 0.29 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_veyron_cockpit)
{
   mapTo = "veyron_cockpit";
   diffuseMap[0] = "vehicles/veyronL1/veyron_cockpit";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_leather01)
{
   mapTo = "veyron_leather01";
   diffuseMap[0] = "vehicles/veyronL1/veyron_leather01";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.368627 0.368627 0.368627 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_leather02)
{
   mapTo = "veyron_leather02";
   diffuseMap[0] = "vehicles/veyronL1/veyron_leather02";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.313726 0.313726 0.313726 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_leather2_stiching)
{
   mapTo = "veyron_leather2_stiching";
   diffuseMap[0] = "vehicles/veyronL1/veyron_leather2_stiching";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.333333 0.333333 0.333333 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_remap_veyron__sec_env_6_spec_)
{
   mapTo = "remap_veyron__sec_env_6_spec_";
   diffuseMap[1] = "vehicles/veyronL1/lega_d2.dds";
   specularPower[0] = "16";
   pixelSpecular[0] = "1";
   specularPower[1] = "16";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "0 0 0 1";
   diffuseColor[1] = "0.72549 0.00392157 0.0235294 1";
   diffuseColor[2] = "0.00392157 0.00392157 0.00392157 0.9";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   useAnisotropic[2] = "1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   cubemap = "BNG_Sky_02_cubemap";
   beamngDiffuseColorSlot = 2;
   materialTag0 = "beamng"; materialTag1 = "vehicle";
   doubleSided = "1";
};

singleton Material(veyronL1_veyron_black)
{
   mapTo = "veyron_black";
   diffuseMap[0] = "vehicles/veyronL1/veyron_black";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.541176 0.541176 0.541176 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_gauges)
{
   mapTo = "veyron_gauges";
   diffuseMap[0] = "vehicles/veyronL1/veyron_gauges";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_aluminium)
{
   mapTo = "veyron_aluminium";
   diffuseMap[0] = "vehicles/veyronL1/veyron_aluminium";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   minnaertConstant[0] = "1.2";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_leather1_stitching)
{
   mapTo = "veyron_leather1_stitching";
   diffuseMap[0] = "vehicles/veyronL1/veyron_leather1_stitching";
   specularPower[0] = "44";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_lcd)
{
   mapTo = "veyron_lcd";
   diffuseMap[0] = "vehicles/veyronL1/veyron_lcd";
   specularPower[0] = "19";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_generic_chassis)
{
   mapTo = "generic_chassis";
   diffuseMap[0] = "vehicles/veyronL1/generic_chassis";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   specular[0] = "0.403922 0.403922 0.403922 1";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_carpet)
{
   mapTo = "veyron_carpet";
   diffuseMap[0] = "vehicles/veyronL1/veyron_carpet";
   specularPower[0] = "19";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_alcantara01)
{
   mapTo = "veyron_alcantara01";
   diffuseMap[0] = "vehicles/veyronL1/veyron_alcantara01";
   specularPower[0] = "36";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
};

singleton Material(veyronL1_veyron_cockpit_1)
{
   mapTo = "veyron_cockpit_1";
   diffuseMap[0] = "veyron_cockpit";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_veyron_leather01_1)
{
   mapTo = "veyron_leather01_1";
   diffuseMap[0] = "veyron_leather01";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_Matte__FF999999__env_25_spec__1)
{
   mapTo = "Matte__FF999999__env_25_spec__1";
   diffuseColor[0] = "0.6 0.6 0.6 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_veyron_cockpit_001)
{
   mapTo = "veyron_cockpit_001";
   diffuseColor[0] = "0.64 0.64 0.64 1";
   specular[0] = "0.0001 0.0001 0.0001 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_veyron_leather01_001)
{
   mapTo = "veyron_leather01_001";
   diffuseColor[0] = "0.996078 0.996078 0.996078 1";
   specular[0] = "0.129412 0.129412 0.129412 1";
   specularPower[0] = "1";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/veyronL1/veyron_leather01.tga";
   beamngDiffuseColorSlot = "2";
   materialTag1 = "vehicle";
   materialTag0 = "beamng";
   pixelSpecular[0] = "1";
};

singleton Material(veyronL1_super_gauges_001)
{
   mapTo = "super_gauges_001";
   diffuseColor[0] = "0.4704 0.4704 0.4704 1";
   specular[0] = "9e-008 9e-008 9e-008 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
};

singleton Material(veyronL1_Matte__FF999999__env_25_spec__001)
{
   mapTo = "Matte__FF999999__env_25_spec__001";
   diffuseColor[0] = "0.48 0.48 0.48 1";
   specular[0] = "0.0001 0.0001 0.0001 1";
   specularPower[0] = "50";
   doubleSided = "1";
   translucentBlendOp = "None";
};
